#!/bin/bash

function modoUso {
	echo "Este sctipt mata los procesos que superen el límite de memoria establecido."
	echo "	 ./script MEMORY "
	echo "MEMOTY = Cantidad de memoria máxima establecida en %"
	echo "Se recomienda sea ejecutado con un usuario con permisos para el comando \"kill\""
	exit 1
}

[[ $1 ]] || modoUso
#USER      PID  %CPU %MEM  VSZ     RSS    TTY   STAT START  TIME  COMMAND
#gdm       1103  0.0  1.5 3302732 122296 tty1   Sl+  nov08   0:05 /usr/bin/gnome-shell
#jbarrad+  1473  2.9  1.9 650000  160672 tty2   Sl+  nov08   2:59 /usr/lib/xorg/Xorg vt2
#jbarrad+  3297 20.7  6.2 2292300 503888 tty2   Sl+  nov08  14:30 /usr/lib/firefox/firefox
#ps aux --sort pmem  | egrep -o '^[^root].+[0-9]{4}+[^0-9].+[0-9]{0,2}+[.]+[dd0-9]{0,2}+[0-9]'
#gdm       1103  0.0  1.5
#jbarrad+  1815  0.0  1.9
#jbarrad+  1473  2.8  1.9

while [ True ]; do

	process_may=$(ps aux --sort pmem  | egrep -o '^[^root].+[0-9]{4}+[^0-9].+[0-9]{0,2}+[.]+[dd0-9]{0,2}+[0-9]' | egrep -o '[0-9]{0,4}+.+([0-9]{0,2}+[.]+[0-9]{0,2})$' | tail -n 1)

	mem=$(echo $process_may | egrep -o '([0-9]{0,2}+[.]+[0-9]{0,2})$' | egrep -o '^[0-9]')

	id_proccess=$(echo $process_may | egrep -o '[0-9]{4}')

	[[ $1 -lt $mem ]] && { kill $id_proccess; } 

	sleep 10
done
