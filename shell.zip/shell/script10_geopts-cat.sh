#!/bin/bash

function modoUso (){
	echo "Muestra contenido de archivos"
	echo "Instrucciones de uso:";
	echo "./script OPCION <Archivo | Directorio>";
	echo "   OPCION:";
	echo "     -f ARCHIVO";
	echo "     -d DIRECTORIO";
	echo "                            @JABM v1.0";
	exit $1;
}

F_OPT="";
F_PAR="";
D_OPT="";
D_PAR="";
[[ $# -le "1" ]] && { echo "Debe colocar una opción"; modoUso 6; }
while getopts ":f:d:" opt; do
	case $opt in
		f)
			F_OPT="1";
			F_PAR="$OPTARG";
			;;
		d)
			D_OPT="1";
			D_PAR="$OPTARG";
			;;
		\?)
			echo "$OPTARG: Opción invalida"
			modoUso 1;
			;;
		:)
			echo "$OPTARG: Se esperava un valor como parametro"
			modoUso 2;
			;;
	esac
done

shift $((OPTIND-1));

function validarParams (){
	[[ $1 ]] && [[ $3 ]] && { echo "No se pueden combinar opciones, elige sólo una"; modoUso 3; }
	[[ $1 ]] && [[ ! -f $2 ]] && { echo "-f: El valor par1 debe ser un archivo"; modoUso 4; }
	[[ $3 ]] && [[ ! -d $4 ]] && { echo "-d: El valor par1 debe ser un directorio"; modoUso 5; }
}

validarParams "$F_OPT" "$F_PAR" "$D_OPT" "$D_PAR"

[[ "$F_OPT" ]] && { cat "$F_PAR"; }

[[ "$D_OPT" ]] && {
	for archivo in $(ls $D_PAR); do
		[[ ! -d $archivo ]] && { cat $D_PAR$archivo; }
	done
}
