#!/bin/bash

#Programa de filtrado
#Jesus Antonio Barradas
#$1 = Directorio
#$2 = Una cadena
function filtro () {
	ls $1 | grep $2

}

if [ ! $2 ]; then
	echo "Se deben recibir 2 parametros"
	exit
fi
if [ -d ]; then
	filtro $1 $2
	exit
fi
