#!/bin/bash
#Este script imprime un número que se incrementa de forma infinita.
trap 'IND=$(($IND+1)); echo -n "$IND.- "' 18
trap "exit" 2
IND=0
while [ True ]; do
	wait
done
