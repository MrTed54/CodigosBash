#!/bin/bash
trap 'echo "Hola";' 18
while [ True ]; do	
	wait
done
