#!/bin/bash
echo "The PID: $$"
REG=0
NUM=0
trap 'echo "$REG$NUM stop"; ' STOP
trap 'echo "$REG$NUM KILL"; ' KILL
trap 'echo "$REG$NUM INT"; ' INT 

echo "Running..."
echo "Execute: kill -? PID"
while [ True ]; do
	sleep 2
	NUM=$(($NUM+1))
done
