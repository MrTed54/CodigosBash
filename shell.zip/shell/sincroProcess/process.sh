#!/bin/bash
#trap "kill -2 $PID1; kill -2 $PID2; " 2
./indi-thread2.sh &
PID1=$!
kill -19 $PID1
./hola-thread1.sh &
PID2=$!
echo "Hijo 2: $PID2"
kill -19 $PID2
echo "Padre: $$"
echo "HIjo 1: $PID1"
while [ True ]; do
	kill -18 $PID1
	sleep 1
	kill -19 $PID1
	kill -18 $PID2
	sleep 1
	kill -19 $PID2
done
