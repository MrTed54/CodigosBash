#!/bin/bash

#Jesus Antonio Barradas Maldonado
#Programa que hacer un script con 2 parametros:
#	$!: Archivo de txt con numeros aleatorios.
#	$2: Un numero
#Se debe imrpmir aquellos numeros del archivo que
#son mayores a $2.

#Se valida que se reciban 2 parametros
if [ ! $2 ]; then  
	echo "Se deben insertar 2 parametros examplo: ./script.sh file.txt #"
	exit;
fi
if [ -a $1 ]; then
	#Se toma cada valor del archivo
	for valida in $(cat $1); do
		if [ $valida -gt $2 ]; then
		echo $valida
		fi
	done
else
	echo "Se debe colocar como parametro 1 un archivo"
	exit;	
fi
