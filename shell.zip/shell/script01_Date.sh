#!/bin/bash
fecha=$(date +%d%m%Y)
echo $fecha
echo "hola mundo" > $fecha.txt
