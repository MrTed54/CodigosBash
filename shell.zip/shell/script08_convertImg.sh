#!/bin/bash

function modoUso (){ 
	echo "#############################################"
	echo "#Se debe tener el paquete imagemagick       #"
	echo "#Se deben recibir los siguientes parametros:#"
	echo "#Param. 1 : Directorio con imagenes         #"
	echo "#Param. 2 : Formato a convertir             #"
	echo "#Param. 3 : Directorio donde se guardaran   #"
	echo "#Example  : ./script /tmp/img .png /tmp/img2#"
	echo "#                 ( ✧≖ ͜ʖ≖)             @JABM#"
	echo "#############################################"
	exit
}

function validaDir(){
	#Esta funcion valida directorios
	if [ ! -d $1 ]; then
		echo "$1 no es un directorio"
		modoUso;
	fi
}

if [ ! $3 ]; then
	modoUso;
fi

let penPar=$#-1 #Valor del penultimo parametro
let cTmp=$penPar-1 #Valor de control
tmpPar="$@" #Respalda los parametros
shift $cTmp #Deja no más los 2 últimos parametros
forUser="$1" #Guarda el formato del usuario
shift #Deja el ultimo parametro
dirUser="$1" #Guarda el directorio a copiar
set $tmpPar #Se restablecen los parametros
#Inicia validacion de directorios
validaDir $dirUser #Valida que el ultimo parametro sea un directorio
cont=1 #cont = No. parametro
for dirTemp in "$@"; do
	if [ $cont -lt $penPar ]; then #si contador es menor al par. del formato
		validaDir $dirTemp
		#echo "Se valido $dirTemp"
	fi
	let cont=$cont+1
done
#termina validacion de directorios
cont2=1
for dir in "$@"; do
	if [ $cont2 -lt $penPar ]; then 
		for arc in $(ls $dir); do
			#echo "file: ${arc%.*}" #Antes arc%.*
			#echo "formato: .${arc##*.}" #Formato del archivo
			dst="$dirUser/${arc%%.*}$forUser"
			echo "src: $dir/$arc dst: $dst"
			#convert "$dir/$arc" "$dst"
		#	let cont2=$cont2+1;
		done
	fi
	let cont2=$cont2+1
done
