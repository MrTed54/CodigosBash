#!/bin/bash

#Recibe un numero variable de directorios
#Copia todos los archivos (no directorios) a un directorio especifico.

function modoUso() {
	echo "Este script se debe utilizar de la siguiente manera"
	echo "El primer parametro es un directorio donde se respaldaran los archivos (no dir)";
	echo "Debe colocar como minimo un segundo parametro de un directorio de donde se tomaran los archivos (no dir)";
	echo "                                                                                  Jesus Antonio Barradas";
	exit;
}
function cpFile (){
	if [ ! -d $2 ]; then
		echo "Err 1 (cpFile): $2 no es un directorio"
		modoUso;
		exit;
	fi
	if [ -d $1 ]; then
		echo "No se copio el directorio $2"
	else
		echo "cp $1 $2 "
		cp $1 $2 #Copia archivo a dest (dir).
	fi
}
function validaDir(){
	#Esta funcion valida directorios
	if [ ! -d $1 ]; then
		echo "$1 no es un directorio"
		modo uso;
		exit;
	fi
}
validaDir $1
validaDir $2
cont=0
for dir in "$@"; do
	if [ $cont -eq 0 ]; then #Bandera para asignar directorio
		pathRes="$dir"
		cont=$(($cont + 1))
		echo "Cont=$cont path=$pathRes"
	fi
	for arch in $(ls $dir); do
		pathFile="$dir/$arch";
		if [ ! -d $dir ]; then
			echo "Se encontro que $dir no es un directorio"
		elif [ -d $arch ]; then
			echo "Se encontro que $pathFile es un directorio, no se copiara"
		else
			cpFile $pathFile $pathRes;
		fi
	done
done
