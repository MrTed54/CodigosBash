#!/bin/bash

function array_may(){
	#Se indican las variables de esta función
	local may=$1
	for i in "$@"; do
		[[ $i -gt $may ]] && may=$i
	done
	echo "El num may es: $may"
}
[[ ! $2 ]] && { echo "Debe colocar minimo 2 valores"; exit 1; }
arre=( "$@" )
#arre=( "1" "5" "3" "2" )
array_may ${arre[@]}
