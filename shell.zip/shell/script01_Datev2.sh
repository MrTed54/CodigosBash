#!/bin/bash

fecha=$(date +%d%m%Y)
ruta="/tmp/$fecha.txt"
comando="cat $ruta"
echo "Hola mundo" >> /tmp/$fecha.txt
echo "Se escribio lo siguiente en /tmp/$fecha.txt"
eval $comando
