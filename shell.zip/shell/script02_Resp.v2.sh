#!/bin/bash
#Debes tener como minimo el permiso de ejecucion.
#Example: ./script02_Resp.v2.sh /tmp/example.txt /user/Dowload : 
#Generate backup /tmp/example.txt -> /user/Dowload/example.txt[date_today]

file=$(basename "$1") #Only name file.
pathDest=$2$file"_$(date +%d%m%Y)" #Path backup

#Generate file backup and add execute user Script
echo $USER > $pathDest
#Copy containt /tmp/example./ to /user/Dowload/example.txt[date_today]
cat $1 >> $pathDest

#
echo Generate backup with path: $pathDest
echo "#Start view Containt backup:"
cat $pathDest
echo "#End view containt backup"
