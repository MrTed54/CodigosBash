#!/bin/bash

cd "/home/$USER"
ls
echo "# # # Absoluta # # #"
echo "* * * /etc  * * *"
ls /etc
echo "* * * /root * * *"
ls /root
echo "* * * /home * * *"
ls /home
echo "* * * /boot * * *"
ls /boot
echo "* * * /bin * * *"
ls /bin
echo "# # # Relativa # # #"
echo "* * * /etc  * * *"
cd /etc
ls
echo "* * * /root * * *"
cd /root
ls
echo "* * * /home * * *"
cd /home
ls
echo "* * * /boot * * *"
cd /boot
ls
echo "* * * /bin * * *"
cd /bin
ls

echo "# # # Directorios # # #"
cd "/home/$USER"
[[ -d practica5 ]] && { echo "El directorio practica5 ya existe"; } || { mkdir practica5; }

[[ -d practica5_copia ]] && { echo "El directorio practiva5_copia ya existe"; } || { mkdir practica5_copia; }

function crear_file (){
	#$1: Archivo
	[[ -a $1 ]] && echo "Ya existe el archivo $1" || touch $1
}

crear_file "practica5/test"
crear_file "practica5/testa"
crear_file "practica5/trastB"
crear_file "practica5/testBa"
crear_file "practica5/testC"
crear_file "practica5/testCa"
crear_file "practica5/testCD"
crear_file "practica5/testCC"

cd practica5_copia
for file in $(ls ../practica5 | grep a$); do
	cp ../practica5/$file ./
done

touch -t 199012201019 ../practica5/test

echo "* * * practica5 * * *"
ls -l ../practica5
echo "* * * practica5_copia * * *"
ls -l
