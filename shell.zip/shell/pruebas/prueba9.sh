#!/bin/bash

function imprimir() { #Puede no llevar "()"
	echo $1; #Este $1 es de la funcion no del script
	echo "Mundo";
}

function sumar() {
	let resultado=$1+$2
	echo $resultado
}
imprimir $2 

#var=$(imprimir $1) #Toma el valor de lo que imprime
#echo $var



sumar $1 $2

num1=$(sumar $1 $2)
num2=$(sumar $3 $5)
sumar $num1 $num2
