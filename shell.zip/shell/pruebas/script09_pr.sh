#!/bin/bash

function modoUso(){
	echo "Modo uso:"
	echo "borrarCopiar OPTION ARCHIVOIN"
	echo "Opciones:"
	echo "	-b: borrar ARCHIVOIN"
	echo "	-c DIROUT: copiar ARCHIVOIN a DIROUT"
	echo "ARCHIVOIN: Archivo a manipular"
	exit 1;
}

B_OPT=""
C_OPT=""
V_OPTC=""
while getopts ":c:b" opt; do
	case $opt in
		c)
			C_OPT="1";
			V_OPTC="$OPTARG";
			;;
		b)
			B_OPT="2";
			;;
		\?)
			echo "Opcion invalida -$OPTARG";
			modoUso;
			;;
		:)
			echo "Se esperaba un parametro en -$OPTARG";
			modoUso;
			;;
	esac
			
done

shift $((OPTIND-1));

function validarParams (){
	
	[[ ! $# -eq 4 ]] && { echo "Faltaron parametros"; modoUso;}

	[[ $1 ]] && [[ $3 ]] && { echo "no se pueden combinar las opciones, elige sólo una"; modoUso; }
	
	[[ $1 ]] && [[ ! -d "$2" ]] && { echo "La opción asociada a -c no es un directorio"; modoUso; }

	[[ ! -f $4 ]] && { echo "$4 no es un archivo"; modoUso; }
}

validarParams "$C_OPT" "$V_OPTC" "$B_OPT" $@
#Valida que se haya seleccionado la opción C
[[ "$C_OPT" ]] && { cp "$1" "$V_OPTC"; exit 0;}

#Valida que se haya seleccionado la opción b
[[ "$B_OPT" ]] && { rm "$1"; exit 0;}
