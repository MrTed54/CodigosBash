#!/bin/bash
#Parametro uno, archivo a respaldar. /tmp/p.txt
#Parametro dos, ruta donde se guarda respaldo. /home/jbarradas/Descargas/
#Se declara el nombre del archivo, -L= filenmae Symbolic link (BASH FILE TESTING)
file="$(basename "$(test -L "$1" && readlink "$1" || echo "$1")")"
pathDest=$2$file"_$(date +%d%m%Y)"
#Se realiza el respaldo: se crea el archivo con nombre del archivo, si no existe se sobreescribira el archivo
#Se agrega el primer renglon el usuario que ejecuta el script
echo $USER > $pathDest
#Se copia lo que hay en el archivo a la ruta destino
cat $1 >> $pathDest
#El siguiente codigo solo sirve para validar que los datos esten bien :D
echo imprime lo que hay en $pathDest
cat $pathDest

