#!/bin/bash
#env es para buscar donde esta algun comando
#Evalua comando, recibe $1 un comando y lo ejecuta

if [ ! "$1" ]; then #Si no pasaron el parametro, entonces
	echo "Se debe pasar un parametro";
	exit;
#else
	
fi
eval $1 &> /dev/null || # direcciona la salida buena o mala al mas alla
	{ #Bloque para control de error gracias a ||
		echo "El comando fallo"; 
		exit;
	} #Se genera bloque
echo "El comando funciono"
# &> : Redirige salida normal y de error.

