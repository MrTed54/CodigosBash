#!/bin/bash
#Para ejecutar esteprograma es necesario poner parametros
#ejemplo:
#./prueba3.sh hola mundo
#mundo
#hola
echo $2
echo $1
