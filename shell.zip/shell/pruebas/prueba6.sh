#!/bin/bash
#Se valida si se reciben dos parametros..
if [ $2 ]; then #Me dice si la cadena es vacia
	echo "pasaste los dos parametros"
else 
	echo "El script debe recibir dos archivos"
fi

#Se valida que sean dos parametros
if [ $2 ]; then
	#Se valida que sean archivos y que tengan permisos
	if [ -r $1 ] && [ -w $2 ]; then #-r: Lectura y -w: Escritura
		cat $1 >> $2;
	else 
		echo "Los parametros deben ser archivos y contar con los permisos adecuados"
	fi
else
	echo "El script debe recibir dos archivos"
fi
		
