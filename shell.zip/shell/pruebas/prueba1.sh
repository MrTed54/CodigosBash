#/bin/bash #No jala en mi pc.
STR="HelloWold!"
echo $STR

