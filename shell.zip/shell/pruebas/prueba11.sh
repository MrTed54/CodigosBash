#!/bin/bash
#Script para conseguir el valor de los parametros.
#for dir in "$@"; do
#	echo "$dir";
#done

echo "No. parametros = $#"

let penPar=$#-1
let cTmp=$penPar-1
echo "Ultimo parametro = $penPar"
echo "valores de todos los parametrso: $@"
echo "Valor del penultimo: $cTmp"
parametros="$@" #guarda los parametros
shift "$cTmp" #Quita el valor de cTmp
directorioPen="$1"
shift
directorioFinal="$1"
set $parametros
echo "Valores de todos los parametros 2: $@"
echo "Valor del ultimo parametro: $directorioFinal"
echo "Valor del penultimo parametro: $directorioPen"
