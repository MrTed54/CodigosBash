#hola='echo "hola"'
HOLA=$(date +%d/%m/%Y) #da la fecha
echo $HOLA