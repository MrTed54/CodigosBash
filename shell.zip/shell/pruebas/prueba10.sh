#!/bin/bash

#Este script recibe un número variable de directorios he imprime todos los archivos que tiene cada directorio, cada impresión ya acompañada de un contador
cont=1
for valor in $@; do
	for archivo in $(ls $valor); do
		echo $cont": $archivo"
		let cont=cont+1;
#		cont=$(($cont+1))
	done
done
