#!/bin/bash

#Prueba read
#echo "Escribe algo: "
#read contenido
#echo "esto es lo que escribiste: $contenido"

#Prueba for
#Cada elemento en algo que me genere una cadena
#for elemento in $( ls ); do #hacer...
#	echo "Elemento: $elemento"
#done #Termina for

#Por cada salto de linea imprime algo

#Prueba 2 
#Imprime cada palabra por separado"
#cadena="Hola mundo feliz"
#for elemento in $cadena; do
#	echo "Elemento: $elemento"
#done

#Prueba 3
#no hace lo que debe
#cadena="Hola mundo feliz"
#echo "Coloque directorio: "
#comando=""
#read $comando;
#for elemento in $($comando "Hola mundo"); do
#	echo "Elemento: $elemento"
#done

#Prueba 4
contador=1
for elemento  in $(ls); do
	echo "Elemento $contador: $elemento";
	contador=$(($contador + 1))
done
