#!/bin/bash
function chr_ascii ()  {
	printf "\\$(printf '%03o' "$1")";
}
function ascii_chr {
	LC_CTYPE=C printf '%d' "'$1"
	echo "Prueba: $LC_C_TYOE"
	echo "$C '%d' '$1"
}

#VAR="$(ascii_chr $1)"
#echo "$VAR"

echo "Inserte una contraseña para el usuario $1: "
read V_PASS
COUNTER=0
L_PASS=${#V_PASS}
B_PASS=1;
echo "Longitud de la contrseña: $L_PASS"

[ $L_PASS -lt 8 ] && { echo "La contraseña debe contener minimo 8 caracteres"; B_PASS="0"; }
CONT=0
#echo "${V_PASS:0: 2}"

#echo "${V_PASS: $CONT: $(($CONT+1))}"
COUNTER=0
B_NUM=0;
B_SIM=0;
B_MAY=0;
B_MIN=0;
B_PSS=""; # Acumula las B anteriores :v
#while [ $B_PSS -ne 4 ]; do

#done

while [ $COUNTER -lt ${#V_PASS} ]; do
#	echo "${V_PASS: $COUNTER: $(($CONTER+1))}"
#	C_INT=$(acii_chr "${V_PASS: $COUNTER: $(($CONTER+1))}")
#	echo "${V_PASS: $COUNTER: $(($CONTER+1))}" | od -An -t dC
	C_INT=$(echo "${V_PASS: $COUNTER: $(($CONTER+1))}" | tr -d "\n"| od -An -t dC)
#	#ascii_chr "${V_PASS: $COUNTER: $(($CONTER+1))}" #> $C_INT
#	C_INT=$LC_TYPE:
	echo ": $C_INT"
	[[ $C_INT -ge 65 ]] && [[ $C_INT -le 90 ]] && { echo "Encontre una mayus :3 ";}
	[[ $C_INT -ge 48 ]] && [[ $C_INT -le 57 ]] && { echo "Encontre un número :D ";}
	[[ $C_INT -ge 97 ]] && [[ $C_INT -le 122 ]] && { echo "Encontre una min :v ";}
	[[ $C_INT -ge 33 ]] && [[ $C_INT -le 47 ]] && { B_SIM=$(($B_SIM+1)); b_SIM="1";}
	[[ $C_INT -ge 58 ]] && [[ $C_INT -le 64 ]] && { B_SIM=$(($B_SIM+1)); b_SIM="1";}
	[[ $C_INT -ge 91 ]] && [[ $C_INT -le 96 ]] && { B_SIM=$(($B_SIM+1)); b_SIM="1";}
	[[ $C_INT -ge 123 ]] && [[ $C_INT -le 254 ]] && { B_SIM=$(($B_SIM+1)); b_SIM="1";}
	COUNTER=$(($COUNTER+1))	
done
