#! /bin/bash
#$1 - recibe una palabra
if [ $1 == "foo" ]; then
	echo "True";
	echo "Coninua then";
else 
	echo "false";
	echo "continua else";

fi
