#!/bin/bash
#$1: FILE1 $2: FILE2 $3:Directory
#Copy FILE1 AND FILE2 to Directory
#Create new directory
mkdir $3
#Copy file to directory
cp $1 $3
cp $2 $3
