#!/bin/bash

function modoUso (){
	echo "Script que regresa la clave asociada al nombre de usuario"
	echo "ejemplo: ./script arc_credencial nombre_usr"	
	exit
}

function valParr (){
	[[ $# -eq 2 ]] || { modoUso; }
	[[ -f $1 ]] || { modoUso; }
}


user_1=$(ccdecypt -c $1)
for user_pass in "$(echo $user_1)";do
	usuario="${user_pass%:*}"
	if [ "$usuario" == "$2" ];then
		echo "Clave del usuario ($2): ${user_pass#*:}"
		exit
	fi
done
echo "No existe el usuario :C"
