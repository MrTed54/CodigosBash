#!/bin/bash

function modoUso(){
	echo "Script para validar palabras claves"
	echo "ejemplo: ./script PALABRA_CLAVE"
	echo "La contraseña debe contar con los siguientes criterios"
	echo "Minimo deben ser 8 caracteres"
	echo "Debe empezar con una letra"
	echo "Debe consistir de letras y digitos"
	echo "Debe tener al menos un digito"
	exit
}
function valParr(){
	#Se valida que se recibieron 8 caracteres minimo
	[ ${#1} -lt 8 ] && { modoUso; }
}

#Se definen variables
COUNTER=0
b_MAY=0
b_MIN=0
b_NUM=0
b_SIM=0
#Fin de definir variables
valParr "$1"
while [ $COUNTER -lt ${#1} ]; do
	#Se mueve entre caracteres, dejando a validar en var C_INT el valor de char a Entero.
        C_INT=$(echo "${1: $COUNTER: $(($CONTER+1))}" | tr -d "\n"| od -An -t dC)
	#Se valida si es una letra (may)
        [[ $C_INT -ge 65 ]] && [[ $C_INT -le 90 ]] && { b_LET="1"; }
	#Se valida que haya números
        [[ $C_INT -ge 48 ]] && [[ $C_INT -le 57 ]] && { b_NUM="1"; }
	#Se valida si es una letra (min)
        [[ $C_INT -ge 97 ]] && [[ $C_INT -le 122 ]] && { b_LET="1"; }
	#Se valida simbolos
        [[ $C_INT -ge 33 ]] && [[ $C_INT -le 47 ]] && { b_SIM="1"; }
        [[ $C_INT -ge 58 ]] && [[ $C_INT -le 64 ]] && { b_SIM="1"; }
        [[ $C_INT -ge 91 ]] && [[ $C_INT -le 96 ]] && { b_SIM="1"; }
        [[ $C_INT -ge 123 ]] && [[ $C_INT -le 254 ]] && { b_SIM="1"; }
	#Si es el primer caracter...
	if [ $COUNTER -eq 1 ];then
		#... es un simbolo
		[[ $b_SIM -eq 1 ]] && { modoUso; }
		#... es un número
		[[ $b_NUM -eq 1 ]] && { modoUso; }
	fi
	
        COUNTER=$(($COUNTER+1))
done
#Se suman los encontrados
let B_PSS=$b_LET+$b_NUM
#Si es menor a 2, significa que no recibio todo lo requerido
[[ $B_PSS -lt 2 ]] && { modoUso; }
