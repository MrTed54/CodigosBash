function modoUso(){
        echo "Script principal para administrar servicio "
	echo "MYSQL vía remota, es necesario ejecutar este primero"
        echo "Ejemplo:"
        echo "  ./script OPCION USUARIO CLAVE DOMINIO PUERTO"
        echo "OPCIONES:"
        echo "  -i : inicia el servicio"
        echo "  -d : detiene el servicio"
        echo "  -r : reinicia el servicio"
        echo "  -s : estatus del servicio"
}
function valParr(){
        [[ $1 -ne 5 ]] && { modoUso; }
}
#echo "Se recibieron: $# parametros"
valParr $#

./eje2_expect.exp $@
