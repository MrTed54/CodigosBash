#!/bin/bash

function modoUso(){
	echo "Script para administrar servicio MYSQL vía remota"
	echo "Ejemplo:"
	echo "	./script OPCION USUARIO CLAVE DOMINIO PUERTO"
	echo "OPCIONES:"
	echo "	-i : inicia el servicio"
	echo "	-d : detiene el servicio"
	echo "	-r : reinicia el servicio"
	echo "	-s : estatus del servicio"
}
function valParr(){
	[[ $1 -ne 5 ]] && { modoUso; }
}
#echo "Se recibieron: $# parametros"
valParr $#
OPCION=0;
while getopts ":idrs" opt; do
        case $opt in
                i)
                        OPCION="start";
                        ;;
                d)
                        OPCION="stop";
                        ;;
                r)
                        OPCION="restart";
			;;
                s)
                        OPCION="status";
			;;
                \?)
                        echo "$OPTARG: Opción invalida"
                        modoUso;
                        ;;
                :)
                        echo "$OPTARG: Se esperava un valor como parametro"
                        modoUso;
                        ;;
        esac
done
[[ $OPCION -eq 0 ]] || { modoUso; }
echo "Opcion: $1 Usuario: $2 Clave: $3 Dominio: $4 Puerto: $5"
ssh -p $5 $1@$4 "systemctl $OPCION mysql
