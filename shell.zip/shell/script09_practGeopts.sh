#!/bin/bash
B_OPT=""
V_OPTC=""
function modoUso(){
        echo "#############################################";
        echo "#Este escript copia o borra archivo	  #";
	echo "#Opciones disponibles:			  #";
	echo "#   -c : Copia archivo			  #";
	echo "#	 Recibe un directorio 			  #";
	echo "#	  -b : Borrará el archivo		  #";
	echo "#	EXAMPLES:				  #";
	echo "# ./script -b a.txt			  #";
	echo "# ./script -c /tmp/dir ./a.txt		  #";
        echo "#                 ( ✧≖ ͜ʖ≖)             @JABM#";
        echo "#############################################";
        exit 1;
}
function delFile (){
	#$1 es el archivo
	if [ ! -a $1]; then
		echo "$1 no es un directorio"
		modoUso;
	fi
	rm $1;
}

function copyFile (){
	#$1 es el archivo $2 directorio
	echo "\$1 es: $1"
	echo "\$2 es: $2"
	if [ ! -a $1 ] || [ ! -d $2 ]; then
		echo "Valide que si sea un directorio y un archivo"
		modoUso;
	fi
	cp $1 $2;
}
while getopts ":c:b" opt; do
	case $opt in
		c)
			B_OPT="1";
			V_OPTC="$OPTARG";
			;;
		b)
			B_OPT="2";
			;;
		\?)
			echo "Opcion invalida -$OPTARG";
			modoUso;
			;;
		:)
			echo "Se esperaba un parametro en -$OPTARG";
			modoUso;
			;;
	esac
			
done
shift $((OPTIND-1));
if [ $B_OPT == "1" ]; then
	copyFile $1 $V_OPTC;
fi
if [ $B_OPT == "2" ]; then
#	echo "Se va a borrar $1"
	delFile $1;
fi

