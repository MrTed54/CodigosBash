#!/bin/bash

#Recibe un numero variable de directorios
#Copia todos los archivos (no directorios) a un directorio especifico.

function modoUso() {
	echo "El primer parametro es un directorio donde se respaldaran los archivos (no dir)";
	echo "Debe colocar como minimo un segundo parametro de un directorio de donde se tomaran los archivos (no dir)";
	exit;
}
function copyFile(){
	echo "### Copiando archivos... ###";
	bande="fals"
	dirRes="res"
	for directorio in  $@; do
		for archivo in $(ls $directorio); do
			if [ $bande == "fals" ]; then
				echo "Pasando if"
				dirRes="$directorio";
				echo "DirRes= $dirRes;"
				bande="tru";
			else
				echo "file: $archivo"
				echo "$directorio/$archivo" "$dirRes";
			fi
			
		done
	done
}

if [ ! -d $@ ]; then #Valida que los parametros sean directorios
	modoUso;
	exit;
fi

copyFile $@

