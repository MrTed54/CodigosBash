#!/bin/bash
#$1 = Interface
#Programa para configurar Router 1 IPv6
function addIPv6 () {
	#$1 = Dir ipv6
	#$2 = interface
	ip addr add $1 dev $2
}
echo "ROUTER 2 (A:A:B::2/64)..."
ip addr show
if [ ! $1 ]; then
	echo "Debe seleccionar una interface como parametro 1"
	exit
fi
IPV6 = "A:A:B::2/64"
echo "Configurando ip a interface..."
addIPv6 $IPV6 $1
echo "Configurando ruta..."
ip -6 route add "A:A:C:1/64" via "A:A:B::1/64" dev $1
