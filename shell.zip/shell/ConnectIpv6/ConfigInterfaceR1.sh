#!/bin/bash

#Programa para configurar Router 1 IPv6
function addIPv6 () {
	#$1 = Dir ipv6
	#$2 = interface
	ip addr add $1 dev $2
}
echo "Iniciando configuracion Router 1..."
ip link show
echo "Seleccione la interface a configurar:"
read interface
echo "¿Desea leantar el servicio de la interfaz seleccionada? (1=Si)?"
read op
if [ $op -eq 1 ]; then
	val = 0
	while [ $val -eq 0 ] do
		ip link set dev $interface up
		echo "Precione 1 cuando la interface se encuentre activa"
		ip link show
		read val
	done
fi #Termina activación de interface
clear
echo "Configurando Router1... en la interface ( $interface )"
ip address
echo "¿Desea configurar una IPv6 a la interface ( $interce ) (1=Si)?"
read op
if [ $op -eq 1 ]; then
	echo "Coloque la direccion IPv6:"
	read ipv6
	addIPv6 $ipv6 $interface
fi

