#!/bin/bash

#Configuración de acces point
#$1 = Interface
if [ ! $1 ]; then
	echo "Se debe colocar como primer parametro la interfaz inhalambrica"
	exit;
fi

echo "Configurando access point de R1"
ip link set dev $1 down #Se baja interface wifi
iwconfig $1 channel 9 #Canal de la tarjeta de red
iwconfig $1 mode ad-hoc #Se descubren nodos para enviar paquetes entre si
iwconfig $1 wlan0 essid 'Machine1' #Nombre de la red
iwconfig $1 wlan key 1234567890 #Contraseña
ip addr add A:A:A::1/64 dev $1 #Se declara la ip
ip link set dev $1 up #Se levanta la interface wifi
