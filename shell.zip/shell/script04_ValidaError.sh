#!/bin/bash
#env es para buscar donde esta algun comando
#Evalua comando, recibe $1 un comando y lo ejecuta

if [ ! "$1" ]; then #Si no pasaron el parametro, entonces
	echo "Se debe pasar un parametro";
	exit;
#else

# $? < error	
fi

eval $1 &> /dev/null
id_err=$?
if [ $id_err -ne 0 ]; then #-n e# Si no es igual a 0
	echo "Se encontro el siguiente clave de error: " $id_err;
	exit;
else
	echo "No se encontraron errores";
fi
# &> : Redirige salida normal y de error.

