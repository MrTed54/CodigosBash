#!/bin/bash

rsync -av --delete -e ssh ./backup progadmon@isfei.ddns.net:./JBarradas

