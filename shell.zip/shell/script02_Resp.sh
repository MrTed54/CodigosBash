#!/bin/bash
#Se copia el archivo del parametro 1 a la ruta del parametro 2.
#Parametros a recibir
#$1=/tmp/a.txt
#$2=/home/jbarradas/Documentos/Programas

#Se declaran las variables
usuario=$(echo $USER) #Usuario que ejecuta el script
fecha=$(date +%d%m%Y) #Fecha de creacion
cd $2

path="$2$1$fecha" #directorio + archivo + fecha
echo $path


#Respalda el archivo con el  nuevo nombre
cp $1 $path 

#Agrega al inicio del archivo el usuario
echo Usuario: $usuario > $path 

#Se agrega el contenido del directorio parametro1 al respaldo
#con el inicio del archivo respaldado.
cat $1 >> $path 

#Las siguientes lineas son de validacion...
echo Se guardo el respaldo en: $path
echo Imprimiendo lo respaldado...
echo ""
cat $path
